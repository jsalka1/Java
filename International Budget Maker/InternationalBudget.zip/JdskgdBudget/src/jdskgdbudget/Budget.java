/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdskgdbudget;

/**
 *
 * @Pawprint: jdskgd
 * @Name: Jacob Salka
 * @Date: 5/08/2020
 * @Assignment: Final Project
 */
public class Budget implements java.io.Serializable{
    private Double budgetAmount;
    private String budgetHistory;
    
    public Budget(){
        
    }
    
    public Budget(Double budgetAmount, String budgetHistory){
        this.budgetAmount = budgetAmount;
        this.budgetHistory = budgetHistory;
    }
    
    public void setbudgetAmount(Double budgetAmount){
        this.budgetAmount = budgetAmount;
    }
    
    public void setBudgetHistory(String budgetHistory){
        this.budgetHistory = budgetHistory;
    }
    
    public Double getbudgetAmount(){
        return budgetAmount;
    }
    
    public String getBudgetHistory(){
        return budgetHistory;
    }
    
}
