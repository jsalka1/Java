/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdskgdbudget;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.stage.FileChooser;

/**
 *
 * @Pawprint: jdskgd
 * @Name: Jacob Salka
 * @Date: 5/08/2020
 * @Assignment: Final Project
 * @Credit:  1. Decimal Format: http://tutorials.jenkov.com/java-internationalization/decimalformat.html
 *           2. Many functions such as "HandleSave" and "HandleOpen" were made by Professor Wergeles in his 
 *                  "SerializationExample(During Class)" Lecture Code
 *           3. Some functions such as "GoToBudgetHistory" was code used Professor Wergeles's 
 *                  "SwitcherExample(During Class)" Lecture Code
 *          
 */
public class JdskgdBudgetController extends Switchable implements Initializable {
    
    @FXML
    private TextField currentBudgetAmountTextField;
    
    @FXML
    private TextField addMoneyAmountTextField;
    
    @FXML
    private TextField addMoneyReasonTextField;
    
    @FXML
    private TextField removeMoneyAmountTextField;
    
    @FXML
    private TextField removeMoneyReasonTextField;
    
    @FXML
    private TextField convertAmountTextField;
    
    @FXML
    private TextField conversionTextField;
    
    @FXML
    private ChoiceBox <String> convertBudgetChoiceBox;
    
    @FXML
    private ChoiceBox <String> convertAmountChoiceBox;
    
    private Double currentBudgetAmountUSD = 0.00;
    
    private double MoneyAmountOtherCurrency = 0.00;
    
    private String budgetHistory = "";
    
    private DecimalFormat decimalFormat;
    
    Budget budget;
    
    private CurrencyConverterManager converter;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setup();
    }
    
    private void setup(){
        ObservableList list = FXCollections.observableArrayList("United States Dollar", "Euro",
            "Mexican Peso", "Canadian Dollar", "Japanese Yen", "Chinese Renminbi", "Hong Kong Dollar", 
            "Australian Dollar");
        
        convertBudgetChoiceBox.setItems(list);
        convertBudgetChoiceBox.setValue("United States Dollar");
        
        convertAmountChoiceBox.setItems(list);
        convertAmountChoiceBox.setValue("United States Dollar");
        
        converter = new CurrencyConverterManager();
        
        //http://tutorials.jenkov.com/java-internationalization/decimalformat.html
        decimalFormat = new DecimalFormat("###,###.##");
        decimalFormat.setGroupingSize(3);
        
        budget = new Budget();
    }

    @FXML
    private void handleAddMoney(ActionEvent event) {
        addRemoveMoney(1);
        addToBudgetHistory("+");
    }
    
    @FXML
    private void handleRemoveMoney(ActionEvent event) {
        addRemoveMoney(-1);
        addToBudgetHistory("-");
    }
    
    @FXML
    private void handleConvertBudget(ActionEvent event){
        MoneyAmountOtherCurrency = getConversion(convertBudgetChoiceBox.getValue(), currentBudgetAmountUSD);
        
        if(MoneyAmountOtherCurrency < 0){}
        else{
            String amountRounded = decimalFormat.format(MoneyAmountOtherCurrency);
            String result = "Your budget of " + currentBudgetAmountUSD + " United States Dollars is equal to " 
                + amountRounded + " " + convertBudgetChoiceBox.getValue() + "s";
            conversionTextField.setText(result);
        }
    }
    
    @FXML
    private void handleConvertAmount(ActionEvent event){
        Double amount = checkString(convertAmountTextField.getText());
        if(amount == null){
            conversionTextField.setText("Error: A number was not given");
            return;
        }
        else{
            MoneyAmountOtherCurrency = getConversion(convertAmountChoiceBox.getValue(), amount);
        }
        
        // Won't display restult if there was an error getting conversion
        if(MoneyAmountOtherCurrency < 0){}
        else{
            String amountRounded = decimalFormat.format(MoneyAmountOtherCurrency);
            String result = convertAmountTextField.getText() + " United States Dollars is equal to " 
                  + amountRounded + " " + convertAmountChoiceBox.getValue() + "s";
            conversionTextField.setText(result);
        }
    }
    
    // Origionally created by Professor Wergeles in "SwitcherExample(DuringClass)" 
    @FXML
    private void handleGoToBudgetHistory(ActionEvent event) {
        Switchable.switchTo("BudgetHistory");
        
        BudgetHistoryController controller = (BudgetHistoryController) getControllerByName("BudgetHistory");
        if (controller != null) {
            if(budgetHistory.equals("")){
                controller.budgetHistory.setText("Add/Subtract from your budget to view History");
            }
            else {
                controller.budgetHistory.setText(budgetHistory);
            }
            controller.currentBudgetAmount.setText(currentBudgetAmountUSD.toString());
        }
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    @FXML
    private void handleSave(ActionEvent event) {
         
        budget = createBudgetFromFormData();
        
        if(budget == null){
            return; 
        }
        
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showSaveDialog(this.getStage());
        
        if (file != null) {
            try {
                FileOutputStream fileOut = new FileOutputStream(file.getPath());
                ObjectOutputStream output = new ObjectOutputStream(fileOut);
                output.writeObject(budget);
                output.close();
                fileOut.close(); 
            } catch (FileNotFoundException ex) {
                String message = "File not found exception occured while saving to " + file.getPath(); 
                displayExceptionAlert(message, ex);   
            } catch (IOException ex) {
                String message = "IOException occured while saving to " + file.getPath();
                displayExceptionAlert(message, ex);
            }
        }        
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    @FXML
    private void handleOpen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            
            try {
                
                FileInputStream fileIn = new FileInputStream(file.getPath());
                ObjectInputStream input = new ObjectInputStream(fileIn);
                
                budget = (Budget) input.readObject();
                
                input.close();
                fileIn.close();
                
                //update UI for the user
                fillFormFromBudget(budget);
                
            } catch (FileNotFoundException ex) {
                String message = "File not found exception occured while opening " + file.getPath(); 
                displayExceptionAlert(message, ex); 
                
            } catch (IOException ex) {
                String message = "IO exception occured while opening " + file.getPath(); 
                displayExceptionAlert(message, ex);
                
            } catch (ClassNotFoundException ex) {
                String message = "Class not found exception occured while opening " + file.getPath(); 
                displayExceptionAlert(message, ex); 
            } catch (Exception ex){
                String message = "Class not found exception occured while opening " + file.getPath(); 
                displayExceptionAlert(message, ex); 
            } 
        }
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    @FXML
    private void handleClose(ActionEvent event) {
        stage.close();
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    @FXML
    public void handleAbout(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Budget/Currency Converter");
        alert.setContentText("This application was developed by Jacob Salka for CS3330 at the University of Missouri.");
        
        TextArea textArea = new TextArea("This application was originally intended to create a budget in any currency format and convert it"
                + " to any other currency. However, the API I managed to implement only allows conversion from USD to a different format."
                + " In the future a different API will be used to allow different conversions. If you want to see other curriencies "
                + "implmented or see a problem with the application please contact \"jdskgd@mail.missouri.edu\" ");
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setMaxWidth(Double.MAX_VALUE);
        textArea.setMaxHeight(Double.MAX_VALUE);

        GridPane expContent = new GridPane();
        expContent.setMaxWidth(Double.MAX_VALUE);
        expContent.add(textArea, 0, 0);
        alert.getDialogPane().setExpandableContent(expContent);
        
        alert.showAndWait();
    }
    
    private void addRemoveMoney(int sign){
        String temp;
        Double amount;
        String reason;
        if(sign > 0){
            temp = addMoneyAmountTextField.getText();
            reason = addMoneyReasonTextField.getText();
        }
        else {
            temp = removeMoneyAmountTextField.getText();
            reason = removeMoneyReasonTextField.getText();
        }
        
        amount = checkString(temp);
        if(reason == null || reason.equals("")){
            String errorMessage = "Enter a reason for adding/removing from yout budget";
            Alert alert = new Alert(AlertType.ERROR, errorMessage);
            alert.setHeaderText("Error: No reason/item was given");
            alert.show();
            return;
        }

        if(amount != null){
            amount *= sign;
            currentBudgetAmountUSD += amount;
        }
            temp = decimalFormat.format(currentBudgetAmountUSD.doubleValue());
            currentBudgetAmountTextField.setText(temp); 
    }
    
    private Double checkString(String amount){
        Double temp;
        try {
            temp = Double.parseDouble(amount);
        } catch (NumberFormatException e) {
            String errorMessage = "Use only numbers (0-9) and (.)";
            Alert alert = new Alert(AlertType.ERROR, errorMessage);
            alert.setHeaderText("Error: Value given was not a number");
            alert.show();
            return null;
        }
        return temp;   
    }
    
    private double getConversion(String country, Double amount){
        conversionTextField.setText("Loading...");
        double rate = converter.getConversion(country);
        
        if(rate > 0){
            return rate * amount;
        }
        else{
            conversionTextField.setText("Sorry, something went wrong retrieving the conversion rate for this country");
            return -100;
        }
    }
    
    private void addToBudgetHistory(String sign){
        String amount;
        String reason;
        String budgetEntry;
        if(sign.equals("+")){
            amount = addMoneyAmountTextField.getText();
            reason = addMoneyReasonTextField.getText();
        }
        else{
            amount = removeMoneyAmountTextField.getText();
            reason = removeMoneyReasonTextField.getText();
        }
        
        if(reason == null || reason.equals("")){}
        else{
            budgetEntry = sign + " $" + amount + " for " + reason + "\n";
            budgetHistory += budgetEntry;
        }
        
    }
    
    private Budget createBudgetFromFormData() {
        Budget budget = new Budget();
        
        budget.setBudgetHistory(budgetHistory);
        budget.setbudgetAmount(currentBudgetAmountUSD);

        return budget;
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    private void fillFormFromBudget(Budget budget) {
        currentBudgetAmountUSD = budget.getbudgetAmount();
        currentBudgetAmountTextField.setText(currentBudgetAmountUSD.toString());
        budgetHistory = budget.getBudgetHistory();
    }
    
    //Origionally created by Professor Wergeles in "SerializaitonExample(DuringClass)"
    private void displayExceptionAlert(String message, Exception ex) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Exception Dialog");
        alert.setHeaderText(ex.getClass().getSimpleName());      
        alert.setContentText(message + "\n\n" + ex.getMessage());

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        String exceptionText = sw.toString();

        Label label = new Label("The exception stacktrace was:");

        TextArea textArea = new TextArea(exceptionText);
        textArea.setEditable(false);
        textArea.setWrapText(true);

        textArea.setMaxWidth(Double.MAX_VALUE);
        textArea.setMaxHeight(Double.MAX_VALUE);
        GridPane.setVgrow(textArea, Priority.ALWAYS);
        GridPane.setHgrow(textArea, Priority.ALWAYS);

        GridPane expContent = new GridPane();
        expContent.setMaxWidth(Double.MAX_VALUE);
        expContent.add(label, 0, 0);
        expContent.add(textArea, 0, 1);

        alert.getDialogPane().setExpandableContent(expContent);
        
        alert.showAndWait();
    }
}
