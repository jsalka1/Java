/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdskgdbudget;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @Pawprint: jdskgd
 * @Name: Jacob Salka
 * @Date: 5/08/2020
 * @Assignment: Final Project
 * @credit:     1) This was the API that was used and it's documentation: https://www.exchangerate-api.com/docs/standard-requests
 *              2) This was the library used to access JSON data: https://github.com/google/gson
 */
public class CurrencyConverterManager implements CurrencyConverter{
    private final String urlString = "https://prime.exchangerate-api.com/v5/3203c8c4c826fdb36776f0e0//latest/USD";
    
    public CurrencyConverterManager(){
        
    }
    
    @Override
    public double getConversion(String country){
        
        URL url;
        HttpURLConnection request;
        JsonElement root;
        JsonObject jsonObj;
        String req_result;
        JsonArray jsonArray;
        JsonArray array;
        double rate;
        
        country = countryConversion(country);
        
        if(country == null || country.equals("")){
            return -100;
        }

        try {
            url = new URL(urlString);
            request = (HttpURLConnection) url.openConnection();
            request.connect();
            root = JsonParser.parseReader(new InputStreamReader((InputStream) request.getContent()));
        } catch (MalformedURLException ex) {
            Logger.getLogger(CurrencyConverterManager.class.getName()).log(Level.SEVERE, null, ex);
            return -100;
        } catch (IOException ex) {
            Logger.getLogger(CurrencyConverterManager.class.getName()).log(Level.SEVERE, null, ex);
            return -100;
        } 
        
        jsonObj = root.getAsJsonObject(); 
        JsonObject test = jsonObj.get("conversion_rates").getAsJsonObject();
        rate = test.get(country).getAsDouble();
        System.out.println(rate);
        return rate;
       
    }
    
    private String countryConversion(String country){
        String temp;
        switch (country) {
            case "United States Dollar":
                temp = "USD";
                break;
            case "Euro":
                temp = "EUR";
                break;
            case "Canadian Dollar":
                temp = "CAD";
                break;
            case "Japanese Yen":
                temp = "JPY";
                break;
            case "Australian Dollar":
                temp = "AUD";
                break;
            case "Mexican Peso":
                temp = "MXN";
                break;
            case "Chinese Renminbi":
                temp = "CNY";
                break;
            case "Hong Kong Dollar":
                temp = "HKD";
                break;
            default:
                temp = null;
                break;
        }
        
        return temp;
    }
    
}
