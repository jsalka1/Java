/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdskgdbudget;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @Pawprint: jdskgd
 * @Name: Jacob Salka
 * @Date: 5/08/2020
 * @Assignment: Final Project
 */
public class BudgetHistoryController extends Switchable implements Initializable {

    @FXML
    protected MenuItem goToJdskgdBudget;
    
    @FXML    
    protected TextField currentBudgetAmount;
    
    @FXML
    protected TextArea budgetHistory;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        

    }
    
    @FXML
    private void handleGoToJdskgdBudget(ActionEvent event) {
        switchTo("JdskgdBudget");
    }
    
}
