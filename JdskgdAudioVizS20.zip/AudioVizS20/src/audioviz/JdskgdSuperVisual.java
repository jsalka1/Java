/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audioviz;

import static java.lang.Integer.min;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author Jacob Salka jdskgd
 * @credit: 1.) Color formula originally made by Professor Wergeles
 *          2.) Used for creating custom polygons
 *                  https://www.tutorialspoint.com/javafx/javafx_2d_shapes.htm 
 *          3.) All of these were used to create and manipulate the arcs
 *                  https://www.tutorialspoint.com/javafx/2dshapes_arc.htm
 *                  https://www.tutorialspoint.com/javafx/2dshapes_types_of_arc.htm
 *                  https://docs.oracle.com/javase/8/javafx/api/javafx/scene/shape/Arc.html
 */
public class JdskgdSuperVisual implements Visualizer {
    private final String name = "Jdskgd Super Visualizer";
    
    private Integer numOfBands;
    private AnchorPane vizPane;
    private final Double bandHeightPercentage = 1.3;
    private final Double minArcRadius = 50.0;  // 10.0
    
    private Double width = 0.0;
    private Double height = 0.0;
    private Double halfWidth = 0.0;
    private Double halfHeight = 0.0;
    
    private Double bandWidth = 0.0;
    private Double bandHeight = 0.0;
    private Double halfBandHeight = 0.0;
    
    private final Double startHue = 260.0;
    
    private Arc[] leftArcs;
    private Arc[] rightArcs;
    Circle circle;
    Polygon top;
    Polygon jStaff;
    Polygon jTail;
    Polygon sBody;
    Rectangle clip;
    
    private int strokeWidth = 5;
    private double arcGap = 4.0;
    private double radius = 40;
    private int minYRadius = 5;

    @Override
    public void start(Integer numBands, AnchorPane vizPane) {
         end();
        
        this.numOfBands = numBands;
        this.vizPane = vizPane;
        
        height = vizPane.getHeight();
        width = vizPane.getWidth();
        halfHeight = height / 2;
        halfWidth = width / 2;
        
        arcGap = ((width / 2) - radius - (numBands * 5)) / (numBands); 
        
        clip = new Rectangle(width, height);
        clip.setLayoutX(0);
        clip.setLayoutY(0);
        vizPane.setClip(clip);
        
        circle = new Circle(width/2, height/2, radius);
        circle.setFill(Color.BLACK);
        vizPane.getChildren().add(circle);
        
        top = new Polygon();
        top.getPoints().addAll(new Double[]{
            halfWidth, halfHeight - 30,
            halfWidth + 20, halfHeight - 23,
            halfWidth + 22, halfHeight -  17,
            halfWidth, halfHeight - 25,
            halfWidth - 22, halfHeight - 17,
            halfWidth - 20, halfHeight - 23,
            halfWidth, halfHeight - 30
        });
        top.setFill(Color.GOLD);
        vizPane.getChildren().add(top);
        
        jStaff = new Polygon();
        jStaff.getPoints().addAll(new Double[]{
            halfWidth - 2, halfHeight - 26,
            halfWidth - 2, halfHeight + 30,
            halfWidth - 7, halfHeight + 28,
            halfWidth - 7, halfHeight - 25,
            halfWidth - 2, halfHeight - 26,  
        });
        jStaff.setFill(Color.GOLD);
        vizPane.getChildren().add(jStaff);
        
        jTail = new Polygon();
        jTail.getPoints().addAll(new Double[]{
            halfWidth - 7, halfHeight + 28,  
            halfWidth - 20, halfHeight + 23,
            halfWidth - 20, halfHeight + 3,
            halfWidth - 15, halfHeight - 2, 
            halfWidth - 15, halfHeight + 20,
            halfWidth - 7, halfHeight + 23,
            halfWidth - 7, halfHeight + 28,
        });
        jTail.setFill(Color.GOLD);
        vizPane.getChildren().add(jTail);
        
        sBody = new Polygon();
        sBody.getPoints().addAll(new Double[]{
            halfWidth + 2, halfHeight - 26,
            halfWidth + 2, halfHeight - 5,
            halfWidth + 15, halfHeight + 3,
            halfWidth + 15, halfHeight + 14,
            halfWidth + 7, halfHeight + 20,
            halfWidth + 7, halfHeight + 5,
            halfWidth + 2, halfHeight + 9, 
            halfWidth + 2, halfHeight + 30,
            halfWidth + 20, halfHeight + 17,
            halfWidth + 20, halfHeight + 1,
            halfWidth + 7, halfHeight - 8,
            halfWidth + 7, halfHeight - 25,
            halfWidth + 2, halfHeight - 26,
        });
        sBody.setFill(Color.GOLD);
        vizPane.getChildren().add(sBody);
        
        
        
        bandWidth = (double) arcGap + strokeWidth;
        bandHeight = height * bandHeightPercentage; 
        
        leftArcs = new Arc[numBands];
        rightArcs = new Arc[numBands];
        
        
        
        for (int i = 0; i < numBands; i++) {
            
            
            Arc arc = new Arc();
            arc.setCenterX((width / 2) - radius - (arcGap * (i + 1)) - (strokeWidth * i));
            arc.setCenterY(height / 2);
            arc.setRadiusX(0);
            arc.setRadiusY(minYRadius);
            arc.setStartAngle(90);
            arc.setLength(180);
            arc.setFill(Color.TRANSPARENT);
            arc.setStroke(Color.hsb(startHue, 1.0, 1.0, 1.0));
            arc.setStrokeWidth(strokeWidth);
            arc.setType(ArcType.OPEN);
            vizPane.getChildren().add(arc);
            leftArcs[i] = arc;
            
            Arc arc2 = new Arc();
            arc2.setCenterX((width / 2) + radius + (arcGap * (i + 1)) + (strokeWidth * i));
            arc2.setCenterY(height / 2);
            arc2.setRadiusX(0);
            arc2.setRadiusY(minYRadius);
            arc2.setStartAngle(90);
            arc2.setLength(180);
            arc2.setFill(Color.TRANSPARENT);
            arc2.setStroke(Color.hsb(startHue, 1.0, 1.0, 1.0));
            arc2.setStrokeWidth(strokeWidth);
            arc2.setType(ArcType.OPEN);
            vizPane.getChildren().add(arc2);
            rightArcs[i] = arc2;
        }
    }

    @Override
    public void end() {
        if (leftArcs != null) {
             for (Arc arc : leftArcs) {
                 vizPane.getChildren().remove(arc);
             }
            leftArcs = null;
            
            for (Arc arc : rightArcs) {
                 vizPane.getChildren().remove(arc);
             }
            rightArcs = null;
        }
        
        if(clip != null){
            clip = null;
            vizPane.setClip(null);
            vizPane.getChildren().remove(circle);
            circle = null;
            vizPane.getChildren().remove(top);
            top = null;
            vizPane.getChildren().remove(jStaff);
            jStaff = null;
            vizPane.getChildren().remove(jTail);
            jTail = null;
            vizPane.getChildren().remove(sBody);
            sBody = null;
            
        }
        
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void draw(double timestamp, double lenght, float[] magnitudes, float[] phases) {
        if (leftArcs == null) {
            return;
        }
        
        Integer num = min(leftArcs.length, magnitudes.length);
        
        
        for(int i = 0; i < num; i++){
            if(magnitudes[i] == -60 && magnitudes.length == 0){
                leftArcs[i].setCenterX((width / 2) - radius - (arcGap * (i + 1)) - (strokeWidth * i));
                leftArcs[i].setRadiusX(0);
                leftArcs[i].setRadiusY(minYRadius);
                leftArcs[i].setStartAngle(90);
                leftArcs[i].setLength(180);
                leftArcs[i].setStroke(Color.hsb(startHue, 1.0, 1.0, 1.0));
                
              
                rightArcs[i].setCenterX((width / 2) + radius + (arcGap * (i + 1)) + (strokeWidth * i));
                rightArcs[i].setRadiusX(0);
                rightArcs[i].setRadiusY(minYRadius);
                rightArcs[i].setStartAngle(-90);
                rightArcs[i].setLength(180);
                rightArcs[i].setStroke(Color.hsb(startHue, 1.0, 1.0, 1.0));
            }
            
            else if(magnitudes[i] == -60 && magnitudes.length > 0){
                double randomColor = Math.random() * 360;
                
                leftArcs[i].setCenterX((width / 2) - radius - (arcGap * (i + 1)) - (strokeWidth * i));
                leftArcs[i].setRadiusX(0);
                leftArcs[i].setRadiusY(minYRadius);
                leftArcs[i].setStartAngle(90);
                leftArcs[i].setLength(180);
                leftArcs[i].setStroke(Color.hsb(randomColor, 1.0, 1.0, 0.2));
                
              
                rightArcs[i].setCenterX((width / 2) + radius + (arcGap * (i + 1)) + (strokeWidth * i));
                rightArcs[i].setRadiusX(0);
                rightArcs[i].setRadiusY(minYRadius);
                rightArcs[i].setStartAngle(-90);
                rightArcs[i].setLength(180);
                rightArcs[i].setStroke(Color.hsb(randomColor, 1.0, 1.0, 0.2));
                
                top.setFill(Color.hsb(randomColor, 1.0, 1.0, 1.0));
                jStaff.setFill(Color.hsb(randomColor, 1.0, 1.0, 1.0));
                jTail.setFill(Color.hsb(randomColor, 1.0, 1.0, 1.0));
                sBody.setFill(Color.hsb(randomColor, 1.0, 1.0, 1.0));
            }
            
            else{
                leftArcs[i].setCenterX(width / 2);
                leftArcs[i].setRadiusX(radius + (arcGap * (i + 1)) + (strokeWidth * i));
                leftArcs[i].setRadiusY(radius + (arcGap * (i + 1)) + (strokeWidth * i));
                leftArcs[i].setStartAngle(180 - ((60 + magnitudes[i]) * 1.7) / 2);
                leftArcs[i].setLength((60 + magnitudes[i]) * 1.7);
                leftArcs[i].setStroke(Color.hsb(startHue - (magnitudes[i] * -6.0), 1.0, 1.0, 1.0));
                
                rightArcs[i].setCenterX(width / 2);
                rightArcs[i].setRadiusX(radius + (arcGap * (i + 1)) + (strokeWidth * i));
                rightArcs[i].setRadiusY(radius + (arcGap * (i + 1)) + (strokeWidth * i));
                rightArcs[i].setStartAngle(-(((60 + magnitudes[i]) * 1.7) / 2));
                rightArcs[i].setLength((60 + magnitudes[i]) * 1.7);
                rightArcs[i].setStroke(Color.hsb(startHue - (magnitudes[i] * -6.0), 1.0, 1.0, 1.0));
               
            }
        }

    }
}
